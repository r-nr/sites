import gym
import numpy as np


action_size = 5
observation_space_shape = (96,96,3)

env = gym.make('CarRacing-v0')


rewards = [1 for i in range(35)]


def reset():

	observation = env.reset()
	
	return observation
	
def close():
	env.close()	

def render():
	env.render()
	
def step(action):
	if action==0:
		observation, reward, done,_ = env.step([-1,0.0,0])
	elif action==1:
		observation, reward, done,_ = env.step([0,0.1,0])
	elif action==2:
		observation, reward, done,_ = env.step([1,0.0,0])
	elif action==3:
		observation, reward, done,_ = env.step([0,0,0.0])
	elif action==4:
		observation, reward, done,_ = env.step([0,0,1])

	
		
	
	reward = reward + 0.08
	
	rewards.pop(0)
	rewards.append(reward)
	if sum(rewards) < 0:
		done = True
		reward = -50
	
	return observation,reward,done,_













