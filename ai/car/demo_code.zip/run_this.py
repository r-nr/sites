import numpy as np
import keras.backend.tensorflow_backend as backend
from keras.models import load_model
import tensorflow as tf
import car_env as env
import logging, os



logging.disable(logging.WARNING)
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"



MEMORY_FRACTION = 0.8
NormFactor = 255

#gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=MEMORY_FRACTION)
#backend.set_session(tf.Session(config=tf.ConfigProto(gpu_options=gpu_options)))






class DQNAgent:
    def __init__(self):
        self.model = load_model('model')

    def get_qs(self, state):
        qs = self.model.predict(np.array(state).reshape(-1, *state.shape) / NormFactor)[0]
        return qs






agent = DQNAgent()

done = True


while True:

    if done:
        current_state = env.reset()


    q = agent.get_qs(current_state)
    action = np.argmax(q)


    new_state, reward, done, _ = env.step(action)
    
    
    env.render()


    current_state = new_state


env.close()






